<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet"  href="../asset/CSS/header.css">
    <title>Plan MY Trip</title>
   
</head>
<body>
    <table>
        <tr>
            <td colspan="2" align="right">
                <a href="../controller/logout.php">Logout</a>
            </td>
        </tr>

        <tr>
            <td align="center">
                <h1>Plan My Trip</h1>
            </td>
        </tr>
    </table>
</body>
</html>
