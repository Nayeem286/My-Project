<?php
session_start();
require_once('../model/NotificationModel.php');
$results='';
$results2='';
if (isset($_POST['submit2'])) {

    $results = ShowNotification();
    $results3 = ShowCroomNotification();
    
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Document</title>
</head>
<body>

    <?php for ($i = 0; $i < count($results); $i++) { ?>
        You booked a room at
        <td><?= $results[$i]['Location'] ?>
        in
        <td><?= $results[$i]['hotel_name'] ?>
        on
        <td><?= $results[$i]['Date'] ?><br>
    <?php } ?>

    <?php for ($i = 0; $i < count($results3); $i++) { ?>
        Room Booking has been cancelled at
        <td><?= $results3[$i]['Location'] ?>
        in Hotel
        <td><?= $results3[$i]['hotel_name'] ?>
        on
        <td><?= $results3[$i]['Date'] ?><br>
    <?php } ?>

    <?php
    if (isset($_SESSION['role'])) {
        if ($_SESSION['role'] == "Admin") {
            echo '<a href="../view/admin_home.php">Go Back to Admin Home</a>';
        } elseif ($_SESSION['role'] == "User") {
            echo '<a href="../view/user_home.php">Go Back to User Home</a>';
        }
    }
    ?>
    
</body>
</html>
